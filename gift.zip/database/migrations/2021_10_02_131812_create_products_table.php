<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("tag_id");
            $table->string('name')->unique();
            $table->decimal('price',8,2);
            $table->bigInteger('total_vote');
            $table->decimal('total_avg',4,2);
            $table->string('code')->unique();
            $table->timestamps();
            $table->foreign('tag_id')->references('id')->on('tags')->onDelete('no action')->onUpdate('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
